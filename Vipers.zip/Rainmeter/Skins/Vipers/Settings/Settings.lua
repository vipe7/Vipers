function Initialize()
end -- fun

-- Auto Update START
function Update()
	GetAutoColor = SKIN:GetVariable('MenuColor')
	GetGamingModePosition = SKIN:GetVariable('GamingModePosition')
	
-- Color Changer
	if GetAutoColor == 'Default' then
		SKIN:Bang('!SetVariable BarColor 2E2E2E')
		SKIN:Bang('!SetVariable SolidColor 1C1C1C')
		SKIN:Bang('!WriteKeyValue variables BarColor 2E2E2E #@#Settings.txt')
		SKIN:Bang('!WriteKeyValue variables SolidColor 1C1C1C #@#Settings.txt')
		SKIN:Bang('!SetOption ValueSettings-Extensions-9 Text #0')
		SKIN:Bang('!SetVariable Color "0080C0"')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-9 LeftMouseUpAction "[!SetVariable BarColor 424242][!SetVariable SolidColor 2E2E2E][!SetOption ValueSettings-Extensions-9 Text Theme1][!SetVariable MenuColor Theme1][!WriteKeyValue variables MenuColor Theme1 #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh *]"')
	elseif GetAutoColor == 'Theme1' then
		SKIN:Bang('!SetVariable BarColor 424242')
		SKIN:Bang('!SetVariable SolidColor 2E2E2E')
		SKIN:Bang('!WriteKeyValue variables BarColor 424242 #@#Settings.txt')
		SKIN:Bang('!WriteKeyValue variables SolidColor 2E2E2E #@#Settings.txt')
		SKIN:Bang('!SetOption ValueSettings-Extensions-9 Text #1')
		SKIN:Bang('!SetVariable Color "0080C0"')
		SKIN:Bang('!SetVariable ExtraExtensions 1')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-9 LeftMouseUpAction "[!SetVariable BarColor 0B3861][!SetVariable SolidColor 0B243B][!SetOption ValueSettings-Extensions-9 Text Theme2][!SetVariable MenuColor Theme2][!WriteKeyValue variables MenuColor Theme2 #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh *]"')
	elseif GetAutoColor == 'Theme2' then
		SKIN:Bang('!SetVariable BarColor 0B3861')
		SKIN:Bang('!SetVariable SolidColor 0B243B')
		SKIN:Bang('!WriteKeyValue variables BarColor 0B3861 #@#Settings.txt')
		SKIN:Bang('!WriteKeyValue variables SolidColor 0B243B #@#Settings.txt')
		SKIN:Bang('!SetOption ValueSettings-Extensions-9 Text #2')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-9 LeftMouseUpAction "[!SetVariable BarColor 0B4C5F][!SetVariable SolidColor 0B2F3A][!SetOption ValueSettings-Extensions-9 Text Theme3][!SetVariable MenuColor Theme3][!WriteKeyValue variables MenuColor Theme3 #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh *]"')
	elseif GetAutoColor == 'Theme3' then
		SKIN:Bang('!SetVariable BarColor 0B4C5F')
		SKIN:Bang('!SetVariable SolidColor 0B2F3A')
		SKIN:Bang('!WriteKeyValue variables BarColor 0B4C5F #@#Settings.txt')
		SKIN:Bang('!WriteKeyValue variables SolidColor 0B2F3A #@#Settings.txt')
		SKIN:Bang('!SetOption ValueSettings-Extensions-9 Text #3')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-9 LeftMouseUpAction "[!SetVariable BarColor 61380B][!SetVariable SolidColor 3B240B][!SetOption ValueSettings-Extensions-9 Text Theme4][!SetVariable MenuColor Theme4][!WriteKeyValue variables MenuColor Theme4 #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh *]"')
	elseif GetAutoColor == 'Theme4' then
		SKIN:Bang('!SetVariable BarColor 61380B')
		SKIN:Bang('!SetVariable SolidColor 3B240B')
		SKIN:Bang('!WriteKeyValue variables BarColor 61380B #@#Settings.txt')
		SKIN:Bang('!WriteKeyValue variables SolidColor 3B240B #@#Settings.txt')
		SKIN:Bang('!SetOption ValueSettings-Extensions-9 Text #4')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-9 LeftMouseUpAction "[!SetVariable BarColor 610B0B][!SetVariable SolidColor 3B0B0B][!SetOption ValueSettings-Extensions-9 Text Theme5][!SetVariable MenuColor Theme5][!WriteKeyValue variables MenuColor Theme5 #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh *]"')
	elseif GetAutoColor == 'Theme5' then
		SKIN:Bang('!SetVariable BarColor 610B0B')
		SKIN:Bang('!SetVariable SolidColor 3B0B0B')
		SKIN:Bang('!WriteKeyValue variables BarColor 610B0B #@#Settings.txt')
		SKIN:Bang('!WriteKeyValue variables SolidColor 3B0B0B #@#Settings.txt')
		SKIN:Bang('!SetOption ValueSettings-Extensions-9 Text #5')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-9 LeftMouseUpAction "[!SetVariable BarColor 8A0808][!SetVariable SolidColor 610B0B][!SetOption ValueSettings-Extensions-9 Text Theme6][!SetVariable MenuColor Theme6][!WriteKeyValue variables MenuColor Theme6 #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh *]"')
	elseif GetAutoColor == 'Theme6' then
		SKIN:Bang('!SetVariable BarColor 8A0808')
		SKIN:Bang('!SetVariable SolidColor 610B0B')
		SKIN:Bang('!WriteKeyValue variables BarColor 8A0808 #@#Settings.txt')
		SKIN:Bang('!WriteKeyValue variables SolidColor 610B0B #@#Settings.txt')
		SKIN:Bang('!SetOption ValueSettings-Extensions-9 Text #6')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-9 LeftMouseUpAction "[!SetVariable BarColor 585858][!SetVariable SolidColor 424242][!SetOption ValueSettings-Extensions-9 Text Theme7][!SetVariable MenuColor Theme7][!WriteKeyValue variables MenuColor Theme7 #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh *]"')
	elseif GetAutoColor == 'Theme7' then
		SKIN:Bang('!SetVariable BarColor 585858')
		SKIN:Bang('!SetVariable SolidColor 424242')
		SKIN:Bang('!WriteKeyValue variables BarColor 585858 #@#Settings.txt')
		SKIN:Bang('!WriteKeyValue variables SolidColor 424242 #@#Settings.txt')
		SKIN:Bang('!SetOption ValueSettings-Extensions-9 Text #7')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-9 LeftMouseUpAction "[!SetVariable BarColor 7F00FF][!SetVariable SolidColor 6600CC][!SetOption ValueSettings-Extensions-9 Text Theme8][!SetVariable MenuColor Theme8][!WriteKeyValue variables MenuColor Theme8 #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh *]"')
	elseif GetAutoColor == 'Theme8' then
		SKIN:Bang('!SetVariable BarColor 7F00FF')
		SKIN:Bang('!SetVariable SolidColor 6600CC')
		SKIN:Bang('!WriteKeyValue variables BarColor 7F00FF #@#Settings.txt')
		SKIN:Bang('!WriteKeyValue variables SolidColor 6600CC #@#Settings.txt')
		SKIN:Bang('!SetOption ValueSettings-Extensions-9 Text #8')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-9 LeftMouseUpAction "[!SetVariable BarColor 6600CC][!SetVariable SolidColor 4C0099][!SetOption ValueSettings-Extensions-9 Text Theme9][!SetVariable MenuColor Theme9][!WriteKeyValue variables MenuColor Theme9 #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh *]"')
	elseif GetAutoColor == 'Theme9' then
		SKIN:Bang('!SetVariable BarColor 6600CC')
		SKIN:Bang('!SetVariable SolidColor 4C0099')
		SKIN:Bang('!WriteKeyValue variables BarColor 6600CC #@#Settings.txt')
		SKIN:Bang('!WriteKeyValue variables SolidColor 4C0099 #@#Settings.txt')
		SKIN:Bang('!SetOption ValueSettings-Extensions-9 Text #9')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-9 LeftMouseUpAction "[!SetVariable BarColor 483D8B][!SetVariable SolidColor 4B0082][!SetOption ValueSettings-Extensions-9 Text Theme10][!SetVariable MenuColor Theme10][!WriteKeyValue variables MenuColor Theme10 #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh *]"')
	elseif GetAutoColor == 'Theme10' then
		SKIN:Bang('!SetVariable BarColor 483D8B')
		SKIN:Bang('!SetVariable SolidColor 4B0082')
		SKIN:Bang('!WriteKeyValue variables BarColor 483D8B #@#Settings.txt')
		SKIN:Bang('!WriteKeyValue variables SolidColor 4B0082 #@#Settings.txt')
		SKIN:Bang('!SetOption ValueSettings-Extensions-9 Text #10')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-9 LeftMouseUpAction "[!SetVariable BarColor 2E2E2E][!SetVariable SolidColor 1C1C1C][!SetOption ValueSettings-Extensions-9 Text Default][!SetVariable MenuColor Default][!WriteKeyValue variables MenuColor Default #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh *]"')
	else
		SKIN:Bang('!SetVariable BarColor 2E2E2E')
		SKIN:Bang('!SetVariable SolidColor 1C1C1C')
		SKIN:Bang('!WriteKeyValue variables BarColor 2E2E2E #@#Settings.txt')
		SKIN:Bang('!WriteKeyValue variables SolidColor 1C1C1C #@#Settings.txt')
		SKIN:Bang('!SetOption ValueSettings-Extensions-9 Text #0')
		SKIN:Bang('!SetVariable Color "0080C0"')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-9 LeftMouseUpAction "[!SetVariable BarColor 424242][!SetVariable SolidColor 2E2E2E][!SetOption ValueSettings-Extensions-9 Text Theme1][!SetVariable MenuColor Theme1][!WriteKeyValue variables MenuColor Theme1 #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh *]"')
	end
-- end Color Changer

-- GamingMode Position
	if GetGamingModePosition == 'BottomRight' then
		SKIN:Bang('!WriteKeyValue variables Xpos "#SCREENAREAWIDTH#" #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!WriteKeyValue variables Ypos "(#SCREENAREAHEIGHT#-13)" #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!WriteKeyValue variables StringAlignPOS RIGHT #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-4b LeftMouseUpAction "[!WriteKeyValue variables GamingModePosition TopLeft #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh]"')
	elseif GetGamingModePosition == 'TopLeft' then
		SKIN:Bang('!WriteKeyValue variables Xpos "0" #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!WriteKeyValue variables Ypos "0" #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!WriteKeyValue variables StringAlignPOS LEFT #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-4b LeftMouseUpAction "[!WriteKeyValue variables GamingModePosition TopCenter #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh]"')
	elseif GetGamingModePosition == 'TopCenter' then
		SKIN:Bang('!WriteKeyValue variables Xpos "(#SCREENAREAWIDTH#/2)" #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!WriteKeyValue variables Ypos "0" #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!WriteKeyValue variables StringAlignPOS CENTER #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-4b LeftMouseUpAction "[!WriteKeyValue variables GamingModePosition TopRight #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh]"')
	elseif GetGamingModePosition == 'TopRight' then
		SKIN:Bang('!WriteKeyValue variables Xpos "#SCREENAREAWIDTH#" #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!WriteKeyValue variables Ypos "0" #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!WriteKeyValue variables StringAlignPOS RIGHT #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-4b LeftMouseUpAction "[!WriteKeyValue variables GamingModePosition BottomLeft #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh]"')
	elseif GetGamingModePosition == 'BottomLeft' then
		SKIN:Bang('!WriteKeyValue variables Xpos "0" #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!WriteKeyValue variables Ypos "(#SCREENAREAHEIGHT#-13)" #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!WriteKeyValue variables StringAlignPOS LEFT #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-4b LeftMouseUpAction "[!WriteKeyValue variables GamingModePosition BottomCenter #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh]"')
	elseif GetGamingModePosition == 'BottomCenter' then
		SKIN:Bang('!WriteKeyValue variables Xpos "(#SCREENAREAWIDTH#/2)" #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!WriteKeyValue variables Ypos "(#SCREENAREAHEIGHT#-13)" #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!WriteKeyValue variables StringAlignPOS CENTER #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-4b LeftMouseUpAction "[!WriteKeyValue variables GamingModePosition BottomRight #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh]"')
	else
		SKIN:Bang('!WriteKeyValue variables Xpos "#SCREENAREAWIDTH#" #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!WriteKeyValue variables Ypos "(#SCREENAREAHEIGHT#-13)" #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!WriteKeyValue variables StringAlignPOS RIGHT #ROOTCONFIGPATH#GamingMode\\GamingMode.ini')
		SKIN:Bang('!SetOption ShapeSettings-Extensions-4b LeftMouseUpAction "[!WriteKeyValue variables GamingModePosition TopLeft #@#Settings.txt][!UpdateMeasure SettingsLua][!Refresh]"')
		SKIN:Bang('[!WriteKeyValue variables GamingModePosition BottomRight #@#Settings.txt][!Refresh]')
	end
-- end GamingMode Position
end