function Initialize()
	GetVer1 = SKIN:GetVariable('CurrentVersion')
	GetVer2 = SKIN:GetVariable('CurrentInstalledVersionNEW')
end -- fun

-- Auto Update START
function Update()




-- Updates Checker
	if GetVer1 ~= GetVer2 then
		SKIN:Bang('!CommandMeasure UpdateNotice Show')
	else
		SKIN:Bang('!SetVariable SystemHidden 0')
	end
-- end Updates Checker
end

