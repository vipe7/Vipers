function Initialize()
	GetVer1 = SKIN:GetVariable('CurrentVersion')
	GetVer2 = SKIN:GetVariable('CurrentInstalledVersionNEW')
end -- fun

-- Auto Update START
function Update()




-- Updates Checker
	if GetVer1 ~= GetVer2 then
		SKIN:Bang('!CommandMeasure SpeechHost "New Update Available"')
		SKIN:Bang('!SetOption ShapeUpdateNotification Hidden 0')
		SKIN:Bang('!SetOption UpdateAvailable Hidden 0')
		SKIN:Bang('!SetOption UpdateAvailableVersion Hidden 0')
	else
		SKIN:Bang('!SetOption ShapeUpdateNotification Hidden 1')
		SKIN:Bang('!SetOption UpdateAvailable Hidden 1')
		SKIN:Bang('!SetOption UpdateAvailableVersion Hidden 1')
	end
-- end Updates Checker
end

