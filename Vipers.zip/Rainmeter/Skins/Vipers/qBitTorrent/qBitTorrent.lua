function Initialize()
	
	normalColor = SKIN:GetVariable('ListFontColor')
	greyColor = SKIN:GetVariable('GreyColor')
	maxTorrents = SELF:GetNumberOption('MaxTorrents')	
	runningState = SKIN:GetMeasure('MeasureProcess')
	measureWebUI = SKIN:GetMeasure('MeasureFeed')
	
	torrentPattern = '{"added_on".-upspeed":.-}'
	namePattern = '"name":"(.-)",'
	sizePattern = '"size":(.-),'
	speedPattern = '"dlspeed":(.-),'
	progressPattern = '"progress":(.-),'
	etaPattern = '"eta":(.-),'
	seedsPattern = '"num_seeds":(.-),'
	peersPattern = '"num_leechs":(.-),'
	statePattern = '"state":"(.-)",'
	
end

function Update()

	isRunning = runningState:GetValue()
	
	if isRunning == 1 then
	
		entireHTML = measureWebUI:GetStringValue()
		
		dummyString, fullCount = string.gsub(entireHTML, torrentPattern, '')
		torrentCount = (fullCount <= maxTorrents) and fullCount or maxTorrents
		
		startPos = 0
		
		for i = 1, torrentCount do
			
			torrentStart, torrentEnd = string.find(entireHTML, torrentPattern, startPos)
			oneTorrent = string.sub(entireHTML, torrentStart, torrentEnd)
			
			torrentName = string.match(oneTorrent, namePattern)
			torrentSize = tonumber(string.match(oneTorrent, sizePattern))
			torrentSpeed = tonumber(string.match(oneTorrent, speedPattern))
			torrentProgress = tonumber(string.match(oneTorrent, progressPattern))
			torrentETA = tonumber(string.match(oneTorrent, etaPattern))
			torrentSeeds = tonumber(string.match(oneTorrent, seedsPattern))
			torrentPeers = tonumber(string.match(oneTorrent, peersPattern))
			torrentState = string.match(oneTorrent, statePattern)

			startPos = torrentEnd + 1
	
			SKIN:Bang('!ShowMeterGroup', 'Torrent'..i)
			SKIN:Bang('!SetOption', 'Meter'..i..'Name', 'Text', torrentName)
			sizeScaled, sizeScale = AutoScale(torrentSize, 1)
			SKIN:Bang('!SetOption', 'Meter'..i..'Size', 'Text', sizeScaled..' '..sizeScale)
			speedScaled, speedScale = AutoScale(torrentSpeed, 1)
			SKIN:Bang('!SetOption', 'Meter'..i..'DLSpeed', 'Text', speedScaled..' '..speedScale..'/s')
			if torrentSpeed == 0 then
				SKIN:Bang('!SetOption', 'Meter'..i..'DLSpeed', 'FontColor', greyColor)
			else
				SKIN:Bang('!SetOption', 'Meter'..i..'DLSpeed', 'FontColor', normalColor)
			end	
			downloadedScaled, downloadedScale = AutoScale((torrentSize * torrentProgress), 1)
			progressPercent = Round((torrentProgress * 100), 0)
			SKIN:Bang('!SetOption', 'Meter'..i..'Percent', 'Text', progressPercent..'%')
			SKIN:Bang('!SetVariable', 'Bar'..i..'Calc', progressPercent)			
			SKIN:Bang('!SetOption', 'Meter'..i..'Seeds', 'Text', torrentSeeds)
			if torrentSeeds == 0 then
				SKIN:Bang('!SetOption', 'Meter'..i..'Seeds', 'FontColor', greyColor)
			else
				SKIN:Bang('!SetOption', 'Meter'..i..'Seeds', 'FontColor', normalColor)
			end				
			
			torrentState = string.gsub(torrentState, 'downloading', 'Downloading')
			torrentState = string.gsub(torrentState, 'queued.+', 'Queued')
			torrentState = string.gsub(torrentState, 'meta.+', 'Metadata')
			torrentState = string.gsub(torrentState, 'stalled.+', 'Stalled')
			torrentState = string.gsub(torrentState, 'paused.+', 'Paused')
			torrentState = string.gsub(torrentState, 'uploading', 'Seeding')
			
			if torrentProgress == 1 then torrentState = 'Completed' end
			
			SKIN:Bang('!SetOption', 'Meter'..i..'Status', 'Text', torrentState)
			
			etaFormated = FormatSeconds(torrentETA)..' remaining'
			if torrentETA == 8640000 then
				if torrentState == 'Completed' then
					etaFormated = 'Completed'
				else
					etaFormated = 'Unknown'
				end
			end
			
			SKIN:Bang('!SetOption', 'Meter'..i..'Name', 'ToolTipTitle', torrentName)
			SKIN:Bang('!SetOption', 'Meter'..i..'Name', 'ToolTipText', 'Torrent: '..i..' of '..fullCount..'#CRLF#'..'Seeds: '..torrentSeeds..' Peers: '..torrentPeers..'#CRLF#'..'Status: '..torrentState..'#CRLF#'..'Downloaded: '..downloadedScaled..' '..downloadedScale..' of '..sizeScaled..' '..sizeScale..'#CRLF#'..'Speed '..speedScaled..' '..speedScale..'/s'..'#CRLF#'..'Estimate: '..etaFormated) 

		end
		
		SKIN:Bang('!EnableMeasureGroup', 'AllMeasures')
		if torrentCount == 0 then
		 SKIN:Bang('!HideMeterGroup', 'Body')
		else	
		 SKIN:Bang('!ShowMeterGroup', 'Body')
		end
		
		SKIN:Bang('!SetVariable', 'BackgroundHeight', tostring(torrentCount * 31))
		
		if torrentCount < maxTorrents then
		 for i = torrentCount + 1, maxTorrents do
			SKIN:Bang('!HideMeterGroup', 'Torrent'..i)
		 end	
		end
	
	else
		
		SKIN:Bang("!DisableMeasureGroup AllMeasures")
		SKIN:Bang("!HideMeterGroup Body")
		for i = 1, maxTorrents do
			SKIN:Bang("!HideMeterGroup Torrent"..i)
		end	
		
	end

	return fullCount
	
end

function FormatSeconds(inputSeconds)
		
		local tableWeeks = inputSeconds / 604800
		local weeksRemainder = inputSeconds % 604800
		local tableDays = weeksRemainder / 86400
		local daysRemainder = weeksRemainder % 86400
		local tableHours = daysRemainder / 3600
		local hoursRemainder = daysRemainder % 3600
		local tableMinutes = hoursRemainder / 60
		local minutesRemainder = hoursRemainder % 60
		local tableSeconds = minutesRemainder % 60		

		local formatTable = {}
		formatTable['weeks'] = math.floor(tableWeeks)
		formatTable['days'] = math.floor(tableDays)
		formatTable['hours'] = math.floor(tableHours)
		formatTable['mins'] = math.floor(tableMinutes)
		formatTable['secs'] = math.floor(tableSeconds)
													
		if formatTable['weeks'] == 1 then weekText = 'week' else weekText = 'weeks' end
		if formatTable['days'] == 1 then dayText = 'day' else dayText = 'days' end
		if formatTable['hours'] == 1 then	hourText = 'hour' else hourText = 'hours' end
		if formatTable['mins'] == 1 then minText = 'minute' else minText = 'minutes' end
		if formatTable['secs'] == 1 then secText = 'second' else secText = 'seconds' end

		if inputSeconds >= 604800 then
			outputString = formatTable['weeks']..' '..weekText..' '..formatTable['days']..' '..dayText..' '..formatTable['hours']..' '..hourText..' '..formatTable['mins']..' '..minText..' '..formatTable['secs']..' '..secText
		elseif inputSeconds >= 86400 then
			outputString = formatTable['days']..' '..dayText..' '..formatTable['hours']..' '..hourText..' '..formatTable['mins']..' '..minText..' '..formatTable['secs']..' '..secText
		elseif inputSeconds >= 3600 then
			outputString = formatTable['hours']..' '..hourText..' '..formatTable['mins']..' '..minText..' '..formatTable['secs']..' '..secText
		elseif inputSeconds >= 60 then
			outputString = formatTable['mins']..' '..minText..' '..formatTable['secs']..' '..secText
		else	
			outputString = formatTable['secs']..' '..secText
		end					
	
	return outputString
	
end

function AutoScale(num, idp)
	assert(tonumber(num), 'AutoScale expects a number.')
	local scales = {'B', 'kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'}
	local places = idp or 0
	local scale = ""
	local scaled = 0

	for i, v in ipairs(scales) do
		if (num < (1024 ^ i)) or (i == #scales) then
			scale = v
			scaled = Round(num / 1024 ^ (i - 1), places)
			break
		end
	end

	return scaled, scale
end

function Round(num, idp)
	assert(tonumber(num), 'Round expects a number.')
	local mult = 10 ^ (idp or 0)
	if num >= 0 then
		return math.floor(num * mult + 0.5) / mult
	else
		return math.ceil(num * mult - 0.5) / mult
	end
end