function Initialize()
	inputMeasure = SKIN:GetMeasure('MeasureFeed')
	torrentPattern = '{"added_on".-}'
	speedPattern = '"dlspeed":(.-),'
	etaPattern = '"eta":(.-),'
	namePattern = '"name":"(.-)",'
	progressPattern = '"progress":(.-),'
end

function Round(num, idp)
	assert(tonumber(num), 'Round expects a number.')
	local mult = 10 ^ (idp or 0)
	if num >= 0 then
		return math.floor(num * mult + 0.5) / mult
	else
		return math.ceil(num * mult - 0.5) / mult
	end
end

function FormatSeconds(secondsArg)

   local weeks = (secondsArg / 604800)
   local rweeks = Round(weeks, 1)
   local remainder = secondsArg % 604800
   local days = (remainder / 86400)
   local rdays = Round(days, 1)
   local remainder = remainder % 86400
   local hours = (remainder / 3600)
   local rhours = Round(hours, 1)
   local remainder = remainder % 3600
   local minutes = (remainder / 60)
   local rminutes = Round(minutes, 1)
   local seconds = remainder % 60
   
   return rweeks, rdays, rhours, rminutes, seconds
   
end

function TimeOutput(num)

   local elapsedSeconds = tonumber(num)
   
   local weeks, days, hours, minutes, seconds = FormatSeconds(elapsedSeconds)
   
   local weeksTxt, daysTxt, hoursTxt, minutesTxt, secondsTxt = ""
   if weeks == 1 then weeksTxt = 'wk' else weeksTxt = 'wks' end
   if days == 1 then daysTxt = 'day' else daysTxt = 'days' end
   if hours == 1 then hoursTxt = 'hr' else hoursTxt = 'hrs' end
   if minutes == 1 then minutesTxt = 'min' else minutesTxt = 'mins' end
   if seconds == 1 then secondsTxt = 'sec' else secondsTxt = 'secs' end
   
   if elapsedSeconds >= 604800 then
      return weeks..' '..weeksTxt
   elseif elapsedSeconds >= 86400 then
      return days..' '..daysTxt
   elseif elapsedSeconds >= 3600 then
      return hours..' '..hoursTxt
   elseif elapsedSeconds >= 60 then
      return minutes..' '..minutesTxt
   else
      return seconds..' '..secondsTxt
   end

end


function ParseFeed()

	SKIN:Bang('!HideMeterGroup', 'qbt')
	
	maxTorrents = tonumber(SELF:GetOption('MaxTorrents', '1'))
	
	entireFeed = inputMeasure:GetStringValue()
	dummyString, torrentCount = string.gsub(entireFeed, '{"added_on"', '')
	startPos = 0
	meterNumber = 1
	
	for i = 1, torrentCount do
	
		torrentStart, torrentEnd = string.find(entireFeed, torrentPattern, startPos)
		oneTorrent = string.sub(entireFeed, torrentStart, torrentEnd)
		downloadSpeed = string.match(oneTorrent, speedPattern)/1000
		rdownloadSpeed = Round(downloadSpeed, 0).." Kb/s"
		etaTime = string.match(oneTorrent, etaPattern)
		retaTime = "ETA "..TimeOutput(etaTime)
		
		if(rdownloadSpeed=="0 Kb/s") then
		
		retaTime = "Paused"
		
		end
			
		
		torrentName = string.match(oneTorrent, namePattern)
		torrentProg = string.match(oneTorrent, progressPattern)*100
		rtorrentProg = Round(torrentProg, 1).." %"
		
		SKIN:Bang('!SetOption', 'qbtMeterSpeed'..meterNumber, 'Text', rdownloadSpeed)
		SKIN:Bang('!SetOption', 'qbtMeterETA'..meterNumber, 'Text', retaTime)
		SKIN:Bang('!SetOption', 'qbtMeterName'..meterNumber, 'Text', torrentName)
		SKIN:Bang('!SetOption', 'qbtMeterProg'..meterNumber, 'Text', rtorrentProg)
		SKIN:Bang('!SetOption', 'qbtProg'..meterNumber, 'Formula', torrentProg)
		SKIN:Bang('!ShowMeterGroup', 'Torrent'..meterNumber)
		meterNumber = meterNumber + 1
			
		if meterNumber > maxTorrents then break end
		
		startPos = torrentEnd + 1
		
	end
	
end